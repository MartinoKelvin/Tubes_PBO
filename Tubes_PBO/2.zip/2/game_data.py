level_0 = {
    'terrain' : './assets/level_0_terrain.csv',
    'coin' : './assets/level_0_coin.csv',
    'enemies' : './assets/level_0_enemies.csv',
    'player' : './assets/level_0_player.csv',
    'grass' : './assets/level_0_grass.csv',
    'constraint' : './assets/level_0_constraint.csv',
    'bg palms' : './assets/level_0_bg_palms.csv',
    'fg palms' : './assets/level_0_fg_palms.csv',
    'crates' : './assets/level_0_crates.csv',

}